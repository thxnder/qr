/* global moment:true */
sap.ui.define([
    
], function() {
    "use strict";
    return {
        URLSOAP: "http://140.20.0.214:8080/sap/bc/srt/rfc/sap/",
        ClientSOAP: "300",
        usernameSOAP: "TTAPIA",
        passwordSOAP: "Seidor2017"
    };
});