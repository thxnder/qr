/* global moment:true */
sap.ui.define([
    
], function() {
    "use strict";
    return {
        AppController: null,
        LoginController: null,
        MenuController: null,
        DlgErroresController: null
    };
});